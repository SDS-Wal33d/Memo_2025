/*
  Warnings:

  - You are about to drop the column `isNotified` on the `attendee` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `attendee` DROP COLUMN `isNotified`;
