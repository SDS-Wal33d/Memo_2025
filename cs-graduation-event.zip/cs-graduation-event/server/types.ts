import app from '.'

export type AppType = typeof app
