-- AlterTable
ALTER TABLE `reservee` ADD COLUMN `isNotified` BOOLEAN NOT NULL DEFAULT false;
